﻿using UnityEngine;
using System.Collections;

public class QuitGame : MonoBehaviour {
	void OnMouseUp(){
		Application.Quit();
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
