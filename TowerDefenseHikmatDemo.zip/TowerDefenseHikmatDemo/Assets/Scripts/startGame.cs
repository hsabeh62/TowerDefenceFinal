﻿using UnityEngine;
using System.Collections;

public class startGame : MonoBehaviour {
	void OnMouseUp(){
		Application.LoadLevel(1);
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
