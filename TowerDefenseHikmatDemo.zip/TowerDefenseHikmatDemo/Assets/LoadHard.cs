﻿using UnityEngine;
using System.Collections;

public class LoadHard : MonoBehaviour {
	void OnMouseUp(){
		Application.LoadLevel(4);
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
