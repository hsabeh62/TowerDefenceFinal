﻿using UnityEngine;
using System.Collections;

public class Pause : MonoBehaviour {
	void OnMouseUp(){
		Time.timeScale = 0;
	}
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
